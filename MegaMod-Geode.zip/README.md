# Mega Mod (Geode)

Сборка .geode:
1. Создай репозиторий на GitHub, залей ВСЕ файлы из этой папки (вместе с .github/workflows/build.yml).
2. Открой вкладку Actions -> Build Geode Mod -> дождись зелёной галочки.
3. Внизу страницы запуска скачай артефакт "Build Output" -> внутри будет gdfan.megamod.geode.
4. Положи .geode в папку geode/mods (или установи через Geode).

Настройки: Geode -> Mods -> Mega Mod -> Settings. Кнопка "Mega" в главном меню применяет валюту.

Если mod.json ругается на версию Geode - поменяй поле "geode" на свою версию.
