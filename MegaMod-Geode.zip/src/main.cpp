#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/GameManager.hpp>
#include <Geode/modify/GameStatsManager.hpp>
#include <Geode/modify/GJGameLevel.hpp>
#include <Geode/modify/CCScheduler.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <cstring>

using namespace geode::prelude;

// ---------------------------------------------------------------- helpers
namespace {
	bool getB(char const* key) { return Mod::get()->getSettingValue<bool>(key); }
	double getD(char const* key) { return Mod::get()->getSettingValue<double>(key); }
	int64_t getI(char const* key) { return Mod::get()->getSettingValue<int64_t>(key); }

	// Если включены читы, прогресс/рекорды не сохраняются и не уходят в лидерборды.
	bool isCheating() {
		return getB("noclip") || getB("jump-hack") || getD("speed") != 1.0;
	}

	void applyFps() {
		auto v = getI("fps-cap");
		if (v > 0) CCDirector::sharedDirector()->setAnimationInterval(1.0 / static_cast<double>(v));
	}

	void applyCurrencies() {
		auto gsm = GameStatsManager::sharedState();
		auto set = [&](char const* statKey, char const* setting) {
			auto v = getI(setting);
			if (v > 0) gsm->setStat(statKey, static_cast<int>(v));
		};
		set("6", "stars");
		set("28", "moons");
		set("14", "orbs");
		set("13", "diamonds");
		set("12", "user-coins");
		set("8", "secret-coins");
		set("5", "demons");
		GameManager::sharedState()->save();
	}
}

// ---------------------------------------------------------------- microphone (FMOD recording)
namespace mic {
	constexpr unsigned RATE = 24000;
	constexpr unsigned SECONDS = 2;
	constexpr unsigned LEN = RATE * SECONDS; // samples in ring buffer

	FMOD::Sound* sound = nullptr;
	unsigned lastPos = 0;
	bool started = false;

	bool start() {
		if (started) return true;
		auto engine = FMODAudioEngine::sharedEngine();
		if (!engine || !engine->m_system) return false;
		auto sys = engine->m_system;

		int drivers = 0, connected = 0;
		if (sys->getRecordNumDrivers(&drivers, &connected) != FMOD_OK || drivers <= 0) {
			log::warn("Voice Jump: микрофон не найден или нет доступа");
			return false;
		}

		FMOD_CREATESOUNDEXINFO info;
		std::memset(&info, 0, sizeof(info));
		info.cbsize = sizeof(info);
		info.numchannels = 1;
		info.format = FMOD_SOUND_FORMAT_PCM16;
		info.defaultfrequency = RATE;
		info.length = LEN * sizeof(short);

		if (sys->createSound(nullptr, FMOD_LOOP_NORMAL | FMOD_OPENUSER, &info, &sound) != FMOD_OK) {
			sound = nullptr;
			return false;
		}
		if (sys->recordStart(0, sound, true) != FMOD_OK) {
			sound->release();
			sound = nullptr;
			return false;
		}
		lastPos = 0;
		started = true;
		return true;
	}

	void stop() {
		if (!started) return;
		auto engine = FMODAudioEngine::sharedEngine();
		if (engine && engine->m_system) engine->m_system->recordStop(0);
		if (sound) sound->release();
		sound = nullptr;
		started = false;
	}

	// Пиковая громкость 0..1 с прошлого вызова
	float level() {
		if (!started || !sound) return 0.f;
		auto engine = FMODAudioEngine::sharedEngine();
		unsigned pos = 0;
		if (engine->m_system->getRecordPosition(0, &pos) != FMOD_OK) return 0.f;
		if (pos == lastPos) return 0.f;

		unsigned count = pos > lastPos ? pos - lastPos : LEN - lastPos + pos;
		void *p1 = nullptr, *p2 = nullptr;
		unsigned l1 = 0, l2 = 0;
		if (sound->lock(lastPos * 2, count * 2, &p1, &p2, &l1, &l2) != FMOD_OK) return 0.f;

		int peak = 0;
		auto scan = [&](void* p, unsigned len) {
			if (!p) return;
			auto s = static_cast<short*>(p);
			for (unsigned i = 0; i < len / 2; i++) {
				int a = std::abs(static_cast<int>(s[i]));
				if (a > peak) peak = a;
			}
		};
		scan(p1, l1);
		scan(p2, l2);
		sound->unlock(p1, p2, l1, l2);
		lastPos = pos;
		return peak / 32768.f;
	}
}

// ---------------------------------------------------------------- PlayLayer: noclip, accuracy, voice jump
class $modify(MegaPlayLayer, PlayLayer) {
	struct Fields {
		int total = 0;
		int bad = 0;
		bool diedThisFrame = false;
		bool killed = false;
		bool micDown = false;
		float quiet = 0.f;
		CCLabelBMFont* label = nullptr;
		CCLabelBMFont* fpsLabel = nullptr;
		float fps = 60.f;
		bool hbOn = false;
	};

	void setupHasCompleted() {
		PlayLayer::setupHasCompleted();
		auto f = m_fields.self();

		auto win = CCDirector::sharedDirector()->getWinSize();
		f->label = CCLabelBMFont::create("", "bigFont.fnt");
		f->label->setScale(0.4f);
		f->label->setAnchorPoint({0.f, 1.f});
		f->label->setPosition({8.f, win.height - 8.f});
		f->label->setOpacity(190);
		f->label->setZOrder(100);
		m_uiLayer->addChild(f->label);

		f->fpsLabel = CCLabelBMFont::create("", "bigFont.fnt");
		f->fpsLabel->setScale(0.4f);
		f->fpsLabel->setAnchorPoint({0.f, 1.f});
		f->fpsLabel->setPosition({8.f, win.height - 26.f});
		f->fpsLabel->setOpacity(190);
		f->fpsLabel->setZOrder(100);
		m_uiLayer->addChild(f->fpsLabel);

		applyFps();

		if (getB("voice-jump")) mic::start();
	}

	void resetLevel() {
		PlayLayer::resetLevel();
		auto f = m_fields.self();
		f->total = 0;
		f->bad = 0;
		f->diedThisFrame = false;
		f->killed = false;
		if (f->micDown) {
			f->micDown = false;
		}
	}

	void destroyPlayer(PlayerObject* player, GameObject* object) {
		bool applies = getB("noclip") &&
			((player == m_player1 && getB("noclip-p1")) || (player == m_player2 && getB("noclip-p2")));
		if (!applies || object == m_anticheatSpike) {
			PlayLayer::destroyPlayer(player, object);
			return;
		}
		m_fields->diedThisFrame = true; // noclip: считаем «смерть», но не умираем
	}

	void postUpdate(float dt) {
		PlayLayer::postUpdate(dt);
		auto f = m_fields.self();

		// ---- Hitboxes
		if (getB("show-hitboxes")) {
			f->hbOn = true;
			m_isDebugDrawEnabled = true;
			this->updateDebugDraw();
		} else if (f->hbOn) {
			f->hbOn = false;
			m_isDebugDrawEnabled = false;
			this->updateDebugDraw();
		}

		// ---- FPS
		if (f->fpsLabel) {
			bool show = getB("show-fps");
			f->fpsLabel->setVisible(show);
			if (show) {
				float d = CCDirector::sharedDirector()->getDeltaTime();
				if (d > 0.f) f->fps = f->fps * 0.9f + (1.f / d) * 0.1f;
				f->fpsLabel->setString(fmt::format("FPS: {:.0f}", f->fps).c_str());
			}
		}

		// ---- Noclip accuracy
		bool noclip = getB("noclip");
		if (noclip && !m_player1->m_isDead && !f->killed) {
			f->total++;
			if (f->diedThisFrame) f->bad++;
			f->diedThisFrame = false;

			float acc = f->total > 0 ? 100.f * (f->total - f->bad) / f->total : 100.f;
			double minAcc = getD("noclip-min-accuracy");
			if (minAcc > 0 && f->total > 60 && acc < minAcc) {
				f->killed = true;
				PlayLayer::destroyPlayer(m_player1, m_anticheatSpike);
			}
			if (f->label) {
				if (getB("show-accuracy")) {
					f->label->setVisible(true);
					f->label->setString(fmt::format("Accuracy: {:.2f}%  Deaths: {}", acc, f->bad).c_str());
				} else {
					f->label->setVisible(false);
				}
			}
		} else if (f->label) {
			f->label->setVisible(noclip && getB("show-accuracy"));
		}

		// ---- Voice jump
		if (getB("voice-jump")) {
			if (!mic::started) mic::start();
			float lvl = mic::level();
			bool loud = lvl > static_cast<float>(getD("voice-threshold"));
			bool dual = m_gameState.m_isDualMode;

			if (loud) {
				f->quiet = 0.f;
				if (!f->micDown) {
					f->micDown = true;
					this->handleButton(true, 1, true);
					if (dual) this->handleButton(true, 1, false);
				}
			} else if (f->micDown) {
				f->quiet += dt;
				if (f->quiet > 0.06f) {
					f->micDown = false;
					this->handleButton(false, 1, true);
					if (dual) this->handleButton(false, 1, false);
				}
			}
		} else if (mic::started) {
			mic::stop();
		}
	}

	void levelComplete() {
		if (isCheating()) m_isTestMode = true; // не сохранять прохождение
		PlayLayer::levelComplete();
	}

	void onQuit() {
		mic::stop();
		PlayLayer::onQuit();
	}
};

// ---------------------------------------------------------------- не сохранять процент при читах
class $modify(MegaLevel, GJGameLevel) {
	void savePercentage(int percent, bool isPracticeMode, int clicks, int attempts, bool isChkValid) {
		if (isCheating()) return;
		GJGameLevel::savePercentage(percent, isPracticeMode, clicks, attempts, isChkValid);
	}
};

// ---------------------------------------------------------------- Speedhack
class $modify(MegaScheduler, CCScheduler) {
	void update(float dt) {
		double s = getD("speed");
		CCScheduler::update(s == 1.0 ? dt : dt * static_cast<float>(s));
	}
};

// ---------------------------------------------------------------- Unlock All
class $modify(MegaGameManager, GameManager) {
	bool isIconUnlocked(int id, IconType type) {
		if (getB("unlock-all")) return true;
		return GameManager::isIconUnlocked(id, type);
	}
	bool isColorUnlocked(int key, UnlockType type) {
		if (getB("unlock-all")) return true;
		return GameManager::isColorUnlocked(key, type);
	}
};

class $modify(MegaStats, GameStatsManager) {
	bool isItemUnlocked(UnlockType type, int key) {
		if (getB("unlock-all")) return true;
		return GameStatsManager::isItemUnlocked(type, key);
	}
};

// ---------------------------------------------------------------- Кнопка в главном меню + валюта
class $modify(MegaMenuLayer, MenuLayer) {
	bool init() {
		if (!MenuLayer::init()) return false;
		applyFps();

		static bool once = false;
		if (!once) {
			once = true;
			if (getB("apply-on-launch")) applyCurrencies();
		}

		if (auto menu = this->getChildByID("bottom-menu")) {
			auto spr = ButtonSprite::create("Mega");
			spr->setScale(0.7f);
			auto btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(MegaMenuLayer::onMega));
			btn->setID("mega-mod-button"_spr);
			menu->addChild(btn);
			menu->updateLayout();
		}
		return true;
	}

	void onMega(CCObject*) {
		createQuickPopup(
			"Mega Mod",
			"Apply stars, moons, orbs, diamonds and coins from the mod settings now?\n"
			"(Values set to 0 are not changed.)",
			"Cancel", "Apply",
			[](FLAlertLayer*, bool applyBtn) {
				if (applyBtn) {
					applyCurrencies();
					Notification::create("Currencies applied!", NotificationIcon::Success)->show();
				}
			}
		);
	}
};

// ---------------------------------------------------------------- Jump Hack + No Death Effect
class $modify(MegaPlayer, PlayerObject) {
	bool pushButton(PlayerButton button) {
		if (getB("jump-hack")) m_isOnGround = true;
		return PlayerObject::pushButton(button);
	}

	void playDeathEffect() {
		if (getB("no-death-effect")) return;
		PlayerObject::playDeathEffect();
	}
};
